// ranges item
const costRange = document.querySelector('#cost-range')
const timeRange = document.querySelector('#time-range')



// current amount under the ranges
const currentCost = document.querySelector('#current-cost')
const currentTime = document.querySelector('#current-time')


const cash = document.querySelector('#cash span')
const duration = document.querySelector('#duration span')
const prepay = document.querySelector('#prepay span')
const installment = document.querySelector('#installment span')


// Event Listener for the current, Under the range Element (instead of x)
costRange.addEventListener('change',(el)=>{
    currentCost.innerText = costRange.value
    cash.innerText = costRange.value
    prepayCalc()
})

timeRange.addEventListener('change',(el)=>{
    currentTime.innerText = timeRange.value
    duration.innerText = timeRange.value
    installmentCalc()
})

let prepayAmount   

function prepayCalc(){   
    prepayAmount =  parseInt(costRange.value) * 0.3
    prepay.innerText = prepayAmount
}


function installmentCalc(){
    let pureTotal = costRange.value - prepayAmount
    console.log(costRange.value - prepayAmount);
    let intTimerange =  parseInt(timeRange.value)
    let sum = 0;
    let result = 0
    for(let i = 1 ; i <= intTimerange ; i++){
        sum += 4
        result +=sum 
        // console.log(sum);
    }
    // console.log(result);
    // installment.innerText =  (((pureTotal * result) / 100) / intTimerange)
    
    installment.innerText = ((pureTotal + (((pureTotal * result) / 100))) / intTimerange)


}


